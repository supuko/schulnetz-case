(() => {
  'use strict';

  // Hide the page right away; revealed once the grades are replaced by crates (or on any failure)
  const root = document.documentElement;
  root.classList.add('sncase-pending');
  const reveal = () => root.classList.remove('sncase-pending');
  setTimeout(reveal, 3000);   // safety net: never leave the page blank

  // ---------- Rarities (6 = best in the Swiss system) ----------
  const RARITIES = [
    { min: 6,   name: 'Rare Special Item', color: '#e4ae39', star: true },
    { min: 5.5, name: 'Covert',            color: '#eb4b4b' },
    { min: 5,   name: 'Classified',        color: '#d32ce6' },
    { min: 4.5, name: 'Restricted',        color: '#8847ff' },
    { min: 4,   name: 'Mil-Spec',          color: '#4b69ff' },
    { min: 3.5, name: 'Industrial Grade',  color: '#5e98d9' },
    { min: 0,   name: 'Consumer Grade',    color: '#b0c3d9' }
  ];
  const rarityOf = g => RARITIES.find(r => g >= r.min);

  const GRADE_RE = /^[1-6](?:[.,]\d{1,2})?$/;
  const parseGrade = t => {
    const s = t.replace(/\s+/g, '');
    return GRADE_RE.test(s) ? parseFloat(s.replace(',', '.')) : null;
  };
  const hash = str => {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return 'g' + (h >>> 0).toString(36);
  };
  const norm = c => c.textContent.trim().replace(/\s+/g, ' ');

  let settings = { enabled: true, sound: true, opened: {} };

  // How the grades on this page look (step size + formatting), so decoy items match the real ones
  let style = { step: 0.5, dec: 1, fixed: false, comma: false };
  function detectStyle(targets) {
    if (!targets.length) return;
    const decOf = t => (t.replace(',', '.').split('.')[1] || '').length;
    const decs = targets.map(t => decOf(t.text));
    const dec = Math.min(2, Math.max(...decs));
    const vals = targets.map(t => t.grade);
    const multOf = m => vals.every(v => Math.abs(v / m - Math.round(v / m)) < 1e-6);
    let step;
    if (multOf(1)) step = 1;
    else if (multOf(0.5)) step = 0.5;
    else if (multOf(0.25)) step = 0.25;
    else step = dec >= 2 ? 0.01 : 0.1;
    style = {
      step, dec,
      fixed: decs.every(d => d === decs[0]) && decs[0] > 0,
      comma: targets.every(t => t.text.includes(',')) ? 1 : targets.some(t => t.text.includes(',')) ? 0.5 : 0
    };
  }
  function fmtDecoy(g) {
    let out = style.fixed ? g.toFixed(style.dec) : String(parseFloat(g.toFixed(2)));
    return Math.random() < style.comma ? out.replace('.', ',') : out;
  }

  // ---------- Find grade cells ----------
  function findTargets() {
    const out = [];
    const seen = new Set();

    const add = (cell, row) => {
      if (seen.has(cell) || cell.dataset.sncase) return;
      const text = cell.textContent.trim();
      const grade = parseGrade(text);
      if (grade === null) return;
      seen.add(cell);
      const cells = row ? [...row.cells] : [];
      const key = hash(row ? cells.map(norm).join('|') : norm(cell.parentElement || cell));
      const label = cells.filter(c => c !== cell).map(norm)
        .filter(x => x.length > 2 && !/^[\d.,:\s-]+$/.test(x))
        .slice(0, 2).join(' · ').slice(0, 90);
      out.push({ cell, text, grade, key, label });
    };

    // 1) Tables with a "Note"/"Noten" header column
    for (const table of document.querySelectorAll('table')) {
      let col = -1, len = 0;
      for (const row of table.rows) {
        const cells = [...row.cells];
        if (col < 0) {
          const i = cells.findIndex(c => /^\s*Noten?\s*$/i.test(c.textContent));
          if (i >= 0) { col = i; len = cells.length; }
        } else if (cells.length === len && cells[col]) {
          add(cells[col], row);
        }
      }
    }

    // 2) Fallback: any table cell containing only a grade
    if (!out.length) {
      document.querySelectorAll('td').forEach(td => add(td, td.parentElement));
    }
    return out;
  }

  // ---------- Audio ----------
  let ac;
  function beep(freq, dur, type, vol, delay = 0) {
    if (!settings.sound) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      if (ac.state === 'suspended') ac.resume();
      const o = ac.createOscillator(), g = ac.createGain();
      const t = ac.currentTime + delay;
      o.type = type; o.frequency.value = freq;
      g.gain.setValueAtTime(vol, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(ac.destination);
      o.start(t); o.stop(t + dur);
    } catch (e) { /* audio is optional */ }
  }
  const tick = () => beep(1300, 0.04, 'square', 0.035);
  function fanfare(rIdx) { // rIdx: 0 = best
    const notes = [[523, 659, 784, 1047, 1319], [523, 659, 784, 1047], [440, 554, 659, 880], [440, 554, 659], [392, 494], [349], [294]][rIdx];
    notes.forEach((f, i) => beep(f, 0.35, 'triangle', 0.12, i * 0.11));
  }

  // ---------- UI ----------
  const el = (tag, cls, html) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  };

  const CRATE_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 8l9-5 9 5v9l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v9"/></svg>`;

  function gradeEl(t) {
    const s = el('span', 'sncase-grade');
    s.style.setProperty('--c', rarityOf(t.grade).color);
    s.textContent = t.text;
    return s;
  }

  function mount(t) {
    t.cell.dataset.sncase = '1';
    const render = () => {
      t.cell.textContent = '';
      if (settings.opened[t.key]) { t.cell.appendChild(gradeEl(t)); return; }
      const b = el('button', 'sncase-btn', CRATE_SVG + '<span>Open</span>');
      b.type = 'button';
      b.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        openCase(t, () => {
          settings.opened[t.key] = true;
          chrome.storage.local.set({ opened: settings.opened });
          render();
        });
      });
      t.cell.appendChild(b);
    };
    render();
  }

  function openCase(t, onDone) {
    const N = 60, WIN = 46, W = 150;
    const pool = [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6];
    const wts  = [1, 1, 2, 3, 5, 8, 14, 18, 20, 14, 5];
    const sum = wts.reduce((a, b) => a + b, 0);
    const pick = () => { let r = Math.random() * sum; for (let i = 0; i < pool.length; i++) { r -= wts[i]; if (r <= 0) return pool[i]; } return 5; };
    const decoy = () => {
      let g = pick();
      if (style.step < 0.5) g += (Math.random() - 0.5) * 0.5;   // spread between the half grades
      g = Math.round(g / style.step) * style.step;
      return Math.min(6, Math.max(1, parseFloat(g.toFixed(2))));
    };

    const ov = el('div', 'sncase-overlay');
    ov.innerHTML = `
      <div class="sncase-modal">
        <button class="sncase-x" aria-label="Close">×</button>
        <div class="sncase-title">SchulNetz Case</div>
        <div class="sncase-sub"></div>
        <div class="sncase-window"><div class="sncase-pointer"></div><div class="sncase-strip"></div></div>
        <div class="sncase-result"></div>
        <button class="sncase-action">Open Case</button>
      </div>`;
    const $ = s => ov.querySelector(s);
    $('.sncase-sub').textContent = t.label || 'Mystery grade';

    const strip = $('.sncase-strip');
    for (let i = 0; i < N; i++) {
      const g = i === WIN ? t.grade : decoy();
      const r = rarityOf(g);
      const it = el('div', 'sncase-item', `<b></b><small></small>`);
      it.style.setProperty('--c', r.color);
      it.querySelector('b').textContent = (r.star ? '★ ' : '') + (i === WIN ? t.text : fmtDecoy(g));
      it.querySelector('small').textContent = r.name;
      strip.appendChild(it);
    }

    let raf = 0, spinning = false, done = false;
    const close = () => { cancelAnimationFrame(raf); document.removeEventListener('keydown', onKey, true); ov.remove(); };
    const onKey = e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onKey, true);
    document.body.appendChild(ov);
    $('.sncase-x').addEventListener('click', close);
    ov.addEventListener('mousedown', e => { if (e.target === ov) close(); });

    const btn = $('.sncase-action');
    btn.addEventListener('click', () => {
      if (done) { close(); return; }
      if (spinning) return;
      spinning = true; btn.disabled = true;

      const winW = $('.sncase-window').clientWidth;
      const jitter = (0.12 + Math.random() * 0.76) * W;      // land somewhere inside the item, like CS
      const target = WIN * W + jitter - winW / 2;
      const dur = 7500 + Math.random() * 1500;
      const t0 = performance.now();
      let last = -1;

      const step = now => {
        const p = Math.min(1, (now - t0) / dur);
        const pos = target * (1 - Math.pow(1 - p, 4));       // fast start, long slow-down
        strip.style.transform = `translate3d(${-pos}px,0,0)`;
        const idx = Math.floor((pos + winW / 2) / W);
        if (idx !== last) { last = idx; if (p < 1) tick(); }
        if (p < 1) raf = requestAnimationFrame(step); else finish();
      };
      raf = requestAnimationFrame(step);
    });

    function finish() {
      done = true;
      const r = rarityOf(t.grade);
      [...strip.children].forEach((c, i) => c.classList.add(i === WIN ? 'win' : 'dim'));
      const res = $('.sncase-result');
      res.style.setProperty('--c', r.color);
      res.innerHTML = `<small></small><span></span>`;
      res.querySelector('small').textContent = (r.star ? '★ ' : '') + r.name;
      res.querySelector('span').textContent = 'You got a ' + t.text + '!';
      fanfare(RARITIES.indexOf(r));
      btn.textContent = 'Collect'; btn.disabled = false;
      onDone();
    }
  }

  // ---------- Init ----------
  function run() {
    try {
      if (!settings.enabled) return;
      const targets = findTargets();
      detectStyle(targets);
      targets.forEach(mount);
    } finally {
      reveal();
    }
  }

  chrome.storage.local.get({ enabled: true, sound: true, opened: {} }, s => {
    settings = s;
    if (!settings.enabled) { reveal(); return; }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run, { once: true });
    else run();
  });
})();
