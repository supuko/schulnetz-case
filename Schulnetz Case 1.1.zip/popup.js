const $ = id => document.getElementById(id);
chrome.storage.local.get({ enabled: true, sound: true, opened: {} }, s => {
  $('enabled').checked = s.enabled;
  $('sound').checked = s.sound;
  $('count').textContent = Object.keys(s.opened).length;
});
$('enabled').addEventListener('change', e => chrome.storage.local.set({ enabled: e.target.checked }));
$('sound').addEventListener('change', e => chrome.storage.local.set({ sound: e.target.checked }));
$('reset').addEventListener('click', () => {
  if (confirm('Re-lock all grades?')) chrome.storage.local.set({ opened: {} }, () => { $('count').textContent = 0; });
});
